PRESS KIT CONTENTS
==================================================
Generated: 2025-09-29T09:45:33.095720Z

FILES
- cover-placeholder.png      (1200x1800) — simple cover for listings
- author-bio.txt             — short bios of both authors
- book-blurb.txt             — 2‑paragraph, media‑friendly blurb
- fact-sheet.txt             — one‑pager with key details
- logo-square.png            — square logo placeholder
- logo-wide.png              — wide logo placeholder

HOW TO USE
- Place the ZIP under your Next.js project: public/press/press-kit.zip
- The site already links to /press/press-kit.zip in the Press Kit section.
